/**
 * GrievancePDF.tsx — @react-pdf/renderer vector PDF document
 * Vector PDF: crisp Bengali text, sharp pie charts, no html2canvas blur.
 */
import React from 'react';
import {
  Document, Page, View, Text, StyleSheet, Font,
} from '@react-pdf/renderer';
import type { AuthorizationState } from '../../common/AuthorizationBlock';
import type { Grievance } from '../shared/types';
import { FLOW_STEPS, STATUS_COLORS, URGENCY_COLORS } from '../shared/constants';

// ── Register Noto Sans Bengali ────────────────────────────────────────────────
// ── Font assets imported via Vite ?url — resolves to absolute URL at build time
// This is required because @react-pdf/renderer fetches fonts in a Web Worker
// where relative paths like '/fonts/...' do not resolve correctly.
import NotoRegularUrl from '../../../assets/fonts/NotoSansBengali-Regular.ttf?url';
import NotoBoldUrl    from '../../../assets/fonts/NotoSansBengali-Bold.ttf?url';

// ── Register Noto Sans Bengali ────────────────────────────────────────────────
Font.register({
  family: 'NotoSans',
  fonts: [
    { src: NotoRegularUrl, fontWeight: 400 },
    { src: NotoBoldUrl,    fontWeight: 700 },
  ],
});

// ── Constants ────────────────────────────────────────────────────────────────
const MONTHS_BN = ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];
const MONTHS_EN = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const URGENCY_KEYS = ['জরুরি','বেশি','মাঝারি','কম'] as const;

const URG_COLOR: Record<string,string> = { 'জরুরি':'#A32D2D','বেশি':'#993C1D','মাঝারি':'#854F0B','কম':'#3B6D11' };
const URG_BG:    Record<string,string> = { 'জরুরি':'#FCEBEB','বেশি':'#FAECE7','মাঝারি':'#FAEEDA','কম':'#EAF3DE' };

// ── Styles ───────────────────────────────────────────────────────────────────
const S = StyleSheet.create({
  page:       { fontFamily:'NotoSans', fontSize:9, padding:'12mm 14mm', color:'#1e293b', backgroundColor:'#fff' },
  coverBand:  { backgroundColor:'#0f2442', padding:14, borderRadius:6, marginBottom:10 },
  coverRow:   { flexDirection:'row', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 },
  kpiGrid:    { flexDirection:'row', borderRadius:4, overflow:'hidden', marginTop:8 },
  kpiCell:    { flex:1, backgroundColor:'rgba(255,255,255,0.10)', padding:8, alignItems:'center', marginRight:1 },
  row2:       { flexDirection:'row', gap:10, marginBottom:12 },
  col:        { flex:1 },
  secLbl:     { fontSize:7, fontWeight:700, color:'#0f2442', borderBottom:'1.5px solid #0f2442', paddingBottom:3, marginBottom:8, textTransform:'uppercase', letterSpacing:0.5 },
  tblHdr:     { flexDirection:'row', backgroundColor:'#1e3a5f', padding:'4px 5px', borderTopLeftRadius:2, borderTopRightRadius:2 },
  tblRow:     { flexDirection:'row', padding:'4px 5px', borderBottom:'1px solid #f1f5f9' },
  tblRowAlt:  { flexDirection:'row', padding:'4px 5px', borderBottom:'1px solid #f1f5f9', backgroundColor:'#f8fafc' },
  tblFoot:    { flexDirection:'row', padding:'4px 5px', backgroundColor:'#f8fafc', borderTop:'1.5px solid #e2e8f0' },
  badge:      { borderRadius:6, paddingHorizontal:4, paddingVertical:1 },
  barWrap:    { flexDirection:'row', alignItems:'flex-end', gap:3, height:65 },
  barCol:     { flex:1, alignItems:'center', gap:1 },
  authRow:    { flexDirection:'row', gap:10, marginTop:8 },
  authBlock:  { flex:1, borderTop:'1px solid #94a3b8', paddingTop:5 },
  footer:     { borderTop:'1px solid #000', paddingTop:5, marginTop:10, flexDirection:'row', justifyContent:'space-between' },
});

// ── Breakdown chart — horizontal bars (SVG pie replaced; react-pdf SVG Path
//    crashes on degenerate arcs e.g. single-slice 100%). ─────────────────────
function BreakdownChart({ items }: { items:{label:string;count:number;color:string}[] }) {
  const total = items.reduce((a,i) => a+i.count, 0);
  if (total === 0) return (
    <View style={{ padding:8, backgroundColor:'#f8fafc', borderRadius:4 }}>
      <Text style={{ fontSize:7, color:'#94a3b8' }}>ডেটা নেই</Text>
    </View>
  );
  return (
    <View style={{ gap:5 }}>
      {items.filter(i=>i.count>0).map((item,idx) => {
        const pct = Math.round((item.count/total)*100);
        return (
          <View key={idx}>
            <View style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:2 }}>
              <Text style={{ fontSize:7, color:'#374151' }}>{item.label}</Text>
              <Text style={{ fontSize:7, color:'#64748b' }}>{item.count} ({pct}%)</Text>
            </View>
            <View style={{ height:8, backgroundColor:'#f1f5f9', borderRadius:2 }}>
              <View style={{ height:8, width:`${pct}%`, backgroundColor:item.color, borderRadius:2 }}/>
            </View>
          </View>
        );
      })}
    </View>
  );
}

function BarChart({ data, total }: { data:{label:string;count:number}[]; total:number }) {
  const max  = Math.max(...data.map(d=>d.count), 1);
  const MAXH = 52;
  return (
    <View style={S.barWrap}>
      {data.map((d,i)=>{
        const h   = Math.max(Math.round((d.count/max)*MAXH), d.count>0?3:0);
        const pct = total>0?Math.round((d.count/total)*100):0;
        return (
          <View key={i} style={S.barCol}>
            <Text style={{ fontSize:6, fontWeight:700, color:'#374151' }}>{d.count}</Text>
            <View style={{ width:'100%', height:MAXH, justifyContent:'flex-end' }}>
              <View style={{ height:h, backgroundColor:'#1e3a5f', borderTopLeftRadius:2, borderTopRightRadius:2, width:'100%' }}/>
            </View>
            <Text style={{ fontSize:5, textAlign:'center' as const, color:'#374151', lineHeight:1 }}>{d.label}</Text>
            <Text style={{ fontSize:5, color:'#64748b' }}>{pct}%</Text>
          </View>
        );
      })}
    </View>
  );
}

// ── Signatory type (resolved from factory authorities by caller) ───────────────
export interface Signatory {
  label: string;
  name:  string;
  desig: string;
  show:  boolean;
}

// ── Props ─────────────────────────────────────────────────────────────────────
export interface GrievancePDFProps {
  grievances:  Grievance[];
  month:       number;
  year:        number;
  lang:        'bn' | 'en';
  auth:        AuthorizationState;
  signatories: Signatory[];   // resolved by caller using useFactory()
  factoryName: string;
  factoryAddr: string;
}

// ── Document ─────────────────────────────────────────────────────────────────
export function GrievancePDFDocument({
  grievances, month, year, lang, signatories, factoryName, factoryAddr,
}: GrievancePDFProps) {
  const t_month = lang==='bn' ? MONTHS_BN[month] : MONTHS_EN[month];
  const today   = new Date().toLocaleDateString('en-GB');
  const lastDay = new Date(year, month+1, 0).getDate();
  const today_ts = Date.now();

  const filtered = grievances.filter(g => {
    if (!g.SubmittedAt) return false;
    const d = new Date(g.SubmittedAt);
    return d.getMonth()===month && d.getFullYear()===year;
  });

  const total = filtered.length;

  const statusRows = FLOW_STEPS.map(s=>({
    label:s.status, color:STATUS_COLORS[s.status]||'#888',
    count:filtered.filter(g=>g.Status===s.status).length,
  }));
  const resolved = filtered.filter(g=>g.Status==='সমাধান হয়েছে'||g.Status==='বন্ধ').length;
  const pending  = total-resolved;

  const urgencyRows = URGENCY_KEYS.map(u=>({
    label:u, color:URG_COLOR[u]||'#888',
    count:filtered.filter(g=>g.Urgency===u).length,
  }));

  const catMap:Record<string,number>={};
  filtered.forEach(g=>{ catMap[g.Category]=(catMap[g.Category]||0)+1; });
  const catRows = Object.entries(catMap).sort((a,b)=>b[1]-a[1]).map(([label,count])=>({label,count}));

  const deptMap:Record<string,number>={};
  filtered.forEach(g=>{ if(g.Department) deptMap[g.Department]=(deptMap[g.Department]||0)+1; });
  const deptRows = Object.entries(deptMap).sort((a,b)=>b[1]-a[1]).map(([label,count])=>({label,count}));

  const avgDays = total>0
    ? (filtered.reduce((a,g)=>{
        const s=g.SubmittedAt?new Date(g.SubmittedAt).getTime():today_ts;
        return a+Math.round((today_ts-s)/86400000);
      },0)/total).toFixed(1)
    : '—';

  const titleText    = lang==='bn'?'কর্মী অভিযোগ মাসিক প্রতিবেদন':'Monthly Employee Grievance Report';
  const confidential = lang==='bn'?'গোপনীয় — শুধুমাত্র অভ্যন্তরীণ ব্যবহার':'Confidential — internal use only';
  const authNote     = lang==='bn'
    ? `এই প্রতিবেদন এইচআর ও কমপ্লায়েন্স বিভাগ কর্তৃক প্রস্তুত। প্রতিবেদনের সময়কাল: ${t_month} 1–${lastDay}, ${year}.`
    : `This report has been prepared by the HR & Compliance Division. Reporting period: ${t_month} 1–${lastDay}, ${year}.`;

  const visibleSigs = signatories.filter(s=>s.show);

  return (
    <Document title={titleText} author={factoryName} creator="RMS V16">
      <Page size="A4" style={S.page} wrap>

        {/* Cover */}
        <View style={S.coverBand}>
          <View style={S.coverRow}>
            <View style={{ flex:1 }}>
              <Text style={{ fontSize:13, fontWeight:700, color:'#fff', marginBottom:2 }}>{factoryName}</Text>
              <Text style={{ fontSize:7,  color:'rgba(255,255,255,0.55)' }}>{factoryAddr}</Text>
              <Text style={{ fontSize:13, fontWeight:700, color:'#fff', marginTop:8 }}>{titleText}</Text>
              <Text style={{ fontSize:7,  color:'rgba(255,255,255,0.5)', marginTop:2 }}>{t_month} 1–{lastDay}, {year}</Text>
            </View>
            <View style={{ alignItems:'flex-end' }}>
              <Text style={{ fontSize:6, color:'rgba(255,255,255,0.5)', marginBottom:2 }}>{lang==='bn'?'মুদ্রণের তারিখ':'Print date'}</Text>
              <Text style={{ fontSize:9, fontWeight:700, color:'#fff' }}>{today}</Text>
            </View>
          </View>
          <View style={S.kpiGrid}>
            {[
              { v:String(total),    l:lang==='bn'?'মোট দাখিল':'Total filed' },
              { v:String(resolved), l:lang==='bn'?'সমাধান':'Resolved'       },
              { v:String(pending),  l:lang==='bn'?'অমীমাংসিত':'Pending'     },
              { v:String(avgDays),  l:lang==='bn'?'গড় দিন':'Avg. days'      },
            ].map(({v,l},i)=>(
              <View key={i} style={S.kpiCell}>
                <Text style={{ fontSize:14, fontWeight:700, color:'#fff' }}>{v}</Text>
                <Text style={{ fontSize:6,  color:'rgba(255,255,255,0.5)', marginTop:2 }}>{l}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* S1 + S2 */}
        <View style={S.row2}>
          <View style={S.col}>
            <Text style={S.secLbl}>{lang==='bn'?'০১  স্ট্যাটাস বিশ্লেষণ':'01  Status breakdown'}</Text>
            <BreakdownChart items={statusRows.map(r=>({label:r.label,count:r.count,color:r.color}))}/>
          </View>
          <View style={S.col}>
            <Text style={S.secLbl}>{lang==='bn'?'০২  জরুরিত্ব বিশ্লেষণ':'02  Urgency breakdown'}</Text>
            <BreakdownChart items={urgencyRows.map(r=>({label:r.label,count:r.count,color:r.color}))}/>
          </View>
        </View>

        {/* S3 + S4 */}
        {(catRows.length>0||deptRows.length>0) && (
          <View style={S.row2}>
            {catRows.length>0&&(
              <View style={S.col}>
                <Text style={S.secLbl}>{lang==='bn'?'০৩  বিভাগভিত্তিক বিশ্লেষণ':'03  Category breakdown'}</Text>
                <BarChart data={catRows} total={total}/>
              </View>
            )}
            {deptRows.length>0&&(
              <View style={S.col}>
                <Text style={S.secLbl}>{lang==='bn'?'০৪  বিভাগ/সেকশনভিত্তিক সারাংশ':'04  Department summary'}</Text>
                <BarChart data={deptRows} total={total}/>
              </View>
            )}
          </View>
        )}

        {/* S5 Case register */}
        <Text style={[S.secLbl,{marginBottom:6}]}>{lang==='bn'?'০৫  মামলা রেজিস্টার':'05  Case register'}</Text>
        {total===0 ? (
          <Text style={{ fontSize:8, color:'#94a3b8', marginBottom:12 }}>{lang==='bn'?'এই মাসে কোনো অভিযোগ নেই।':'No grievances filed this month.'}</Text>
        ) : (
          <View style={{ marginBottom:12, border:'1px solid #e2e8f0', borderRadius:4, overflow:'hidden' }}>
            {/* Header */}
            <View style={S.tblHdr}>
              {[
                {w:'10%',l:lang==='bn'?'তারিখ':'Date'},
                {w:'17%',l:lang==='bn'?'কেস আইডি':'Case ID'},
                {w:'12%',l:lang==='bn'?'কর্মী':'Worker'},
                {w:'18%',l:lang==='bn'?'বিভাগ/সেকশন':'Dept'},
                {w:'16%',l:lang==='bn'?'ধরন':'Category'},
                {w:'14%',l:lang==='bn'?'স্ট্যাটাস':'Status'},
                {w:'9%', l:lang==='bn'?'জরুরিত্ব':'Urgency'},
                {w:'4%', l:lang==='bn'?'দিন':'Days'},
              ].map(({w,l},i)=>(
                <View key={i} style={{ width:w }}>
                  <Text style={{ fontSize:7, fontWeight:700, color:'#fff' }}>{l}</Text>
                </View>
              ))}
            </View>
            {/* Rows */}
            {filtered.map((g,idx)=>{
              const daysOpen = g.SubmittedAt
                ? Math.round((today_ts-new Date(g.SubmittedAt).getTime())/86400000) : 0;
              const isDone    = g.Status==='সমাধান হয়েছে'||g.Status==='বন্ধ';
              const isOverdue = !isDone && daysOpen>5;
              const sClr = STATUS_COLORS[g.Status]||'#888';
              const uBg  = URG_BG[g.Urgency]   ||'#f8fafc';
              const uClr = URG_COLOR[g.Urgency] ||'#374151';
              const uBdr = URGENCY_COLORS[g.Urgency]?.border||'#e2e8f0';
              return (
                <View key={g.ID} style={idx%2===0?S.tblRow:S.tblRowAlt} wrap={false}>
                  <View style={{ width:'10%' }}>
                    <Text style={{ fontSize:6, color:'#64748b' }}>{g.SubmittedAt?new Date(g.SubmittedAt).toLocaleDateString('en-GB'):'—'}</Text>
                  </View>
                  <View style={{ width:'17%' }}>
                    <Text style={{ fontSize:6, color:'#0f2442', fontWeight:700 }}>{g.ID}</Text>
                  </View>
                  <View style={{ width:'12%' }}>
                    <Text style={{ fontSize:6, color:'#374151' }}>{g.EmployeeID==='ANON'?(lang==='bn'?'বেনামী':'Anon'):(g.Name||'—')}</Text>
                  </View>
                  <View style={{ width:'18%' }}>
                    <Text style={{ fontSize:6, color:'#475569' }}>{g.Department||'—'}</Text>
                  </View>
                  <View style={{ width:'16%' }}>
                    <Text style={{ fontSize:6, color:'#475569' }}>{g.Category||'—'}</Text>
                  </View>
                  <View style={{ width:'14%' }}>
                    <View style={[S.badge,{ backgroundColor:sClr+'20', borderColor:sClr+'55', borderWidth:1 }]}>
                      <Text style={{ fontSize:6, color:sClr, fontWeight:700 }}>{g.Status}</Text>
                    </View>
                  </View>
                  <View style={{ width:'9%' }}>
                    <View style={[S.badge,{ backgroundColor:uBg, borderColor:uBdr, borderWidth:1 }]}>
                      <Text style={{ fontSize:6, color:uClr, fontWeight:700 }}>{g.Urgency}</Text>
                    </View>
                  </View>
                  <View style={{ width:'4%' }}>
                    <Text style={{ fontSize:6, color:isOverdue?'#A32D2D':'#374151', fontWeight:isOverdue?700:400 }}>
                      {daysOpen}{isOverdue?' ⚠':''}
                    </Text>
                  </View>
                </View>
              );
            })}
            {/* Footer */}
            <View style={S.tblFoot}>
              <View style={{ flex:1 }}><Text style={{ fontSize:7, fontWeight:700 }}>{lang==='bn'?'সর্বমোট':'Total'}</Text></View>
              <View style={{ width:'4%' }}><Text style={{ fontSize:7, fontWeight:700 }}>{total}</Text></View>
            </View>
          </View>
        )}

        {/* S6 Authorisation */}
        <Text style={S.secLbl}>{lang==='bn'?'০৬  অনুমোদন':'06  Authorisation'}</Text>
        <Text style={{ fontSize:7, color:'#64748b', marginBottom:8, lineHeight:1.5 }}>{authNote}</Text>
        {visibleSigs.length>0&&(
          <View style={S.authRow}>
            {visibleSigs.map((s,i)=>(
              <View key={i} style={S.authBlock}>
                <Text style={{ fontSize:7, fontWeight:700, color:'#0f2442' }}>{s.name||'_______________'}</Text>
                <Text style={{ fontSize:6, color:'#64748b', marginTop:1 }}>{s.label}</Text>
                <Text style={{ fontSize:6, color:'#94a3b8', marginTop:1 }}>{s.desig}</Text>
                <Text style={{ fontSize:5, color:'#94a3b8', marginTop:4 }}>{lang==='bn'?'স্বাক্ষর ও তারিখ':'Signature & date'}</Text>
              </View>
            ))}
          </View>
        )}

        {/* Footer */}
        <View style={S.footer} fixed>
          <Text style={{ fontSize:6, color:'#374151' }}>{factoryName} · {confidential}</Text>
          <Text style={{ fontSize:6, color:'#374151' }}>RMS V16 · {t_month} {year}</Text>
        </View>

      </Page>
    </Document>
  );
}